const express = require('express');
const bodyParser = require('body-parser');
const promClient = require('prom-client'); 
const collectDefaultMetrics = promClient.collectDefaultMetrics;
const app = express();
const port = 3000;


collectDefaultMetrics();

app.use(bodyParser.json());

app.get('/metrics', (req, res) => {
  res.set('Content-Type', promClient.register.contentType);
  res.end(promClient.register.metrics());
});

let productos = [
  { id: 1, nombre: 'Camiseta', descripcion: 'Camiseta de algodón', precio: 20, cantidad: 100 },
  { id: 2, nombre: 'Pantalón', descripcion: 'Pantalón de mezclilla', precio: 40, cantidad: 50 }
];

app.get('/productos', (req, res) => {
  res.json(productos);
});

app.post('/productos', (req, res) => {
  const producto = req.body;
  productos.push(producto);
  res.status(201).json(producto);
});

app.put('/productos/:id', (req, res) => {
  const { id } = req.params;
  const productoIndex = productos.findIndex(p => p.id == id);
  if (productoIndex !== -1) {
    productos[productoIndex] = req.body;
    res.json(productos[productoIndex]);
  } else {
    res.status(404).send('Producto no encontrado');
  }
});

app.delete('/productos/:id', (req, res) => {
  const { id } = req.params;
  productos = productos.filter(p => p.id != id);
  res.status(204).send();
});

module.exports = app;